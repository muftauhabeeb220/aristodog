
<?php $__env->startSection('content'); ?>
    <div class="pt-120 pb-120">
        <div class="container">
            <div class="row">
                <?php if(auth()->user()->referrer): ?>
                    <h4 class="mb-2"><?php echo app('translator')->get('You are referred by'); ?> <?php echo e(auth()->user()->referrer->fullname); ?></h4>
                <?php endif; ?>
                <div class="col-md-12">
                    <div class="form-group">
                        <div class="input-group">
                            <input class="form-control form-control-lg referralURL" type="text" value="<?php echo e(route('home')); ?>?reference=<?php echo e(auth()->user()->username); ?>" readonly>
                            <button class="input-group-text bg--base -bottom-left-copytext" id="copyBoard" type="button"><i class="fas fa-copy"></i></button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <?php if($user->allReferrals->count() > 0 && $maxLevel > 0): ?>
                                <div class="treeview-container">
                                    <ul class="treeview">
                                        <li class="items-expanded"> <?php echo e($user->fullname); ?> ( <?php echo e($user->username); ?> )
                                            <?php echo $__env->make($activeTemplate . 'partials.under_tree', ['user' => $user, 'layer' => 0, 'isFirst' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </li>
                                    </ul>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style-lib'); ?>
    <link type="text/css" href="<?php echo e(asset($activeTemplateTrue . '/css/jquery.treeView.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script-lib'); ?>
    <script src="<?php echo e(asset($activeTemplateTrue . '/js/jquery.treeView.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('style'); ?>
    <style type="text/css">
        .content-wrapper {
            margin-top: -90px;
            min-height: calc(100vh - 157px);
        }

        .copytext {
            cursor: pointer;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        (function($) {
            "use strict";
            $('.treeview').treeView();

            $('#copyBoard').click(function() {
                var copyText = document.getElementsByClassName("referralURL");
                copyText = copyText[0];
                copyText.select();
                copyText.setSelectionRange(0, 99999);
                /*For mobile devices*/
                document.execCommand("copy");
                copyText.blur();
                this.classList.add('copied');
                setTimeout(() => this.classList.remove('copied'), 1500);
            });
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/odds_frenzy/core/resources/views/templates/basic/user/referrals.blade.php ENDPATH**/ ?>