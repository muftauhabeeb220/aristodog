<?php $__env->startSection('content'); ?>
    <section class="pt-120 pb-120">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="card-body h-100 middle-el">
                        <div class="alt"></div>
                        <div class="game-details-left">
                            <div class="game-details-left__body">
                                <div class="flp">
                                    <div id="coin-flip-cont">
                                        <div class="flipcoin" id="coin">
                                            <div class="flpng coins-wrapper">
                                                <div class="front"><img src="<?php echo e(asset($activeTemplateTrue . 'images/play/head.png')); ?>" alt=""></div>
                                                <div class="back"><img src="<?php echo e(asset($activeTemplateTrue . 'images/play/tail.png')); ?>" alt=""></div>
                                            </div>
                                            <div class="headCoin d-none">
                                                <div class="front"><img src="<?php echo e(asset($activeTemplateTrue . 'images/play/head.png')); ?>" alt=""></div>
                                                <div class="back"><img src="<?php echo e(asset($activeTemplateTrue . 'images/play/tail.png')); ?>" alt=""></div>
                                            </div>
                                            <div class="tailCoin d-none">
                                                <div class="front"><img src="<?php echo e(asset($activeTemplateTrue . 'images/play/tail.png')); ?>" alt=""></div>
                                                <div class="back"><img src="<?php echo e(asset($activeTemplateTrue . 'images/play/head.png')); ?>" alt=""></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="cd-ft"></div>
                    </div>
                </div>
                <div class="col-lg-6 mt-lg-0 mt-5">
                    <div class="game-details-right">
                        <form id="game" method="post">
                            <?php echo csrf_field(); ?>
                            <h3 class="f-size--28 mb-4 text-center"><?php echo app('translator')->get('Current Balance :'); ?> <span class="base--color"><span class="bal"><?php echo e(showAmount(auth()->user()->balance)); ?></span> <?php echo e(__($general->cur_text)); ?></span>
                            </h3>
                            <div class="form-group">
                                <div class="input-group mb-3">
                                    <input class="form-control amount-field" name="invest" type="text" value="<?php echo e(old('invest')); ?>" placeholder="<?php echo app('translator')->get('Enter amount'); ?>">
                                    <span class="input-group-text" id="basic-addon2"><?php echo e(__($general->cur_text)); ?></span>
                                </div>
                                <small class="form-text text-muted"><i class="fas fa-info-circle mr-2"></i><?php echo app('translator')->get('Minimum'); ?>
                                    : <?php echo e(showAmount($game->min_limit)); ?> <?php echo e(__($general->cur_text)); ?> | <?php echo app('translator')->get('Maximum'); ?>
                                    : <?php echo e(showAmount($game->max_limit)); ?> <?php echo e(__($general->cur_text)); ?> | <span class="text--warning"><?php echo app('translator')->get('Win Amount'); ?> <?php if($game->invest_back == 1): ?>
                                            <?php echo e(showAmount($game->win + 100)); ?>

                                        <?php else: ?>
                                            <?php echo e(showAmount($game->win)); ?>

                                        <?php endif; ?> %</span></small>
                            </div>
                            <div class="form-group justify-content-center d-flex mt-5">
                                <div class="single-select head gmimg">
                                    <img src="<?php echo e(asset($activeTemplateTrue . '/images/play/head.png')); ?>" alt="game-image">
                                </div>
                                <div class="single-select tail gmimg">
                                    <img src="<?php echo e(asset($activeTemplateTrue . '/images/play/tail.png')); ?>" alt="game-image">
                                </div>
                                <input name="choose" type="hidden">
                            </div>
                            <div class="mt-5 text-center">
                                <button class="cmn-btn w-100 game text-center" id="flip" type="submit"><?php echo app('translator')->get('Play Now'); ?></button>
                                <a class="game-instruction mt-2" data-bs-toggle="modal" data-bs-target="#exampleModalCenter"><?php echo app('translator')->get('Game Instruction'); ?> <i class="las la-info-circle"></i></a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Modal -->
    <div class="modal fade" id="exampleModalCenter" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content section--bg">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle"><?php echo app('translator')->get('Game Rule'); ?></h5>
                    <button class="btn-close" data-bs-dismiss="modal" type="button" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <?php echo $game->instruction ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style-lib'); ?>
    <link href="<?php echo e(asset($activeTemplateTrue . 'css/coinflipping.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('script-lib'); ?>
    <script type="text/javascript" src="<?php echo e(asset($activeTemplateTrue . 'js/coin.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        "use strict";
        $('#game').on('submit', function(e) {
            e.preventDefault();
            $('.flipcoin').removeClass('animateClick');
            $('.flpng').removeClass('d-none');
            $('#coin .headCoin').addClass('d-none');
            $('#coin .tailCoin').addClass('d-none');

            $('.cmn-btn').html('<i class="la la-gear fa-spin"></i> Processing...');
            $('.cmn-btn').attr('disabled', true);
            var data = $(this).serialize();
            var url = "<?php echo e(route('user.play.game.invest', 'head_tail')); ?>";
            game(data, url);
        });

        function endGame(data) {
            var url = "<?php echo e(route('user.play.game.end', 'head_tail')); ?>";
            complete(data, url);
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/odds_frenzy/core/resources/views/templates/basic/user/games/head_tail.blade.php ENDPATH**/ ?>