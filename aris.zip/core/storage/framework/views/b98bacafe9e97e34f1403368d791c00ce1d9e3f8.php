
<?php $__env->startSection('content'); ?>
    <div class="pt-120 pb-120">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body p-0">
                            <div class="table--responsive">
                                <table class="style--two table">
                                    <thead>
                                        <tr>
                                            <th><?php echo app('translator')->get('Game Name'); ?></th>
                                            <th><?php echo app('translator')->get('You Select'); ?></th>
                                            <th><?php echo app('translator')->get('Result'); ?></th>
                                            <th><?php echo app('translator')->get('Invest'); ?></th>
                                            <th><?php echo app('translator')->get('Win or Lost'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td>
                                                    <span class="text-end"><?php echo e(__($log->game->name)); ?></span>
                                                </td>
                                                <td>
                                                    <div>
                                                        <?php if(gettype(json_decode($log->user_select)) == 'array'): ?>
                                                            <?php echo e(implode(', ', json_decode($log->user_select))); ?>

                                                        <?php else: ?>
                                                            <?php echo e(__($log->user_select)); ?>

                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div>
                                                        <?php if(gettype(json_decode($log->result)) == 'array'): ?>
                                                            <?php echo e(implode(', ', json_decode($log->result))); ?>

                                                        <?php else: ?>
                                                            <?php echo e(__($log->result)); ?>

                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                                <td><span><?php echo e($general->cur_sym); ?><?php echo e(getAmount($log->invest)); ?></span> </td>
                                                <td>
                                                    <?php if($log->win_status != Status::LOSS): ?>
                                                        <span class="badge badge--success"><i class="las la-smile"></i> <?php echo app('translator')->get('Win'); ?></span>
                                                    <?php else: ?>
                                                        <span class="badge badge--danger"><i class="las la-frown"></i> <?php echo app('translator')->get('Lost'); ?></span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td class="text-center" colspan="100%"><?php echo e(__($emptyMessage)); ?></td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <?php if($logs->hasPages()): ?>
                            <div class="card-footer">
                                <?php echo e(paginateLinks($logs)); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/odds_frenzy/core/resources/views/templates/basic/user/game_log.blade.php ENDPATH**/ ?>