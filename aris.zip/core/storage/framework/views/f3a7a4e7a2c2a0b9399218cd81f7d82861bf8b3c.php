<?php $__env->startSection('content'); ?>
<section class="pt-120 pb-120">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="card-body h-100 middle-el overflow-hidden">
                    <div class="game-details-left">
                        <div class="fly">
                            <div class="d-none" id="cards"></div>
                            <div class="flying text-center">
                                <div class="card-holder">
                                    <div class="back"></div>
                                    <div class="flying-card clubs">
                                        <img class="w-100" src="<?php echo e(asset($activeTemplateTrue . 'images/play/cards/01.png')); ?>">
                                    </div>
                                </div>
                                <div class="card-holder">
                                    <div class="back"></div>
                                    <div class="flying-card clubs">
                                        <img class="w-100" src="<?php echo e(asset($activeTemplateTrue . 'images/play/cards/34.png')); ?>">
                                    </div>
                                </div>
                                <div class="card-holder">
                                    <div class="back"></div>
                                    <div class="flying-card clubs">
                                        <img class="w-100" src="<?php echo e(asset($activeTemplateTrue . 'images/play/cards/20.png')); ?>">
                                    </div>
                                </div>
                                <div class="card-holder">
                                    <div class="back"></div>
                                    <div class="flying-card clubs">
                                        <img class="w-100" src="<?php echo e(asset($activeTemplateTrue . 'images/play/cards/29.png')); ?>">
                                    </div>
                                </div>
                                <div class="card-holder">
                                    <div class="back"></div>
                                    <div class="flying-card clubs">
                                        <img class="w-100" src="<?php echo e(asset($activeTemplateTrue . 'images/play/cards/09.png')); ?>">
                                    </div>
                                </div>
                                <div class="card-holder">
                                    <div class="back"></div>
                                    <div class="flying-card clubs">
                                        <img class="w-100" src="<?php echo e(asset($activeTemplateTrue . 'images/play/cards/53.png')); ?>">
                                    </div>
                                </div>
                                <div class="card-holder">
                                    <div class="back"></div>
                                    <div class="flying-card clubs">
                                        <img class="w-100" src="<?php echo e(asset($activeTemplateTrue . 'images/play/cards/2.png')); ?>">
                                    </div>
                                </div>
                                <div class="card-holder">
                                    <div class="back"></div>
                                    <div class="flying-card clubs">
                                        <img class="w-100" src="<?php echo e(asset($activeTemplateTrue . 'images/play/cards/52.png')); ?>">
                                    </div>
                                </div>
                                <div class="card-holder">
                                    <div class="back"></div>
                                    <div class="flying-card clubs">
                                        <img class="w-100" src="<?php echo e(asset($activeTemplateTrue . 'images/play/cards/36.png')); ?>">
                                    </div>
                                </div>
                                <div class="card-holder">
                                    <div class="back"></div>
                                    <div class="flying-card clubs">
                                        <img class="w-100" src="<?php echo e(asset($activeTemplateTrue . 'images/play/cards/25.png')); ?>">
                                    </div>
                                </div>
                                <div class="card-holder">
                                    <div class="back"></div>
                                    <div class="flying-card clubs">
                                        <img class="w-100" src="<?php echo e(asset($activeTemplateTrue . 'images/play/cards/40.png')); ?>">
                                    </div>
                                </div>
                                <div class="card-holder">
                                    <div class="back"></div>
                                    <div class="flying-card clubs">
                                        <img class="w-100" src="<?php echo e(asset($activeTemplateTrue . 'images/play/cards/30.png')); ?>">
                                    </div>
                                </div>
                                <div class="card-holder">
                                    <div class="back"></div>
                                    <div class="flying-card clubs">
                                        <img class="w-100" src="<?php echo e(asset($activeTemplateTrue . 'images/play/cards/19.png')); ?>">
                                    </div>
                                </div>
                                <div class="card-holder">
                                    <div class="back"></div>
                                    <div class="flying-card clubs">
                                        <img class="w-100" src="<?php echo e(asset($activeTemplateTrue . 'images/play/cards/53.png')); ?>">
                                    </div>
                                </div>
                                <div class="card-holder">
                                    <div class="back"></div>
                                    <div class="flying-card clubs">
                                        <img class="w-100" src="<?php echo e(asset($activeTemplateTrue . 'images/play/cards/13.png')); ?>">
                                    </div>
                                </div>
                                <div class="card-holder">
                                    <div class="back"></div>
                                    <div class="flying-card clubs">
                                        <img class="w-100" src="<?php echo e(asset($activeTemplateTrue . 'images/play/cards/51.png')); ?>">
                                    </div>
                                </div>
                                <div class="card-holder">
                                    <div class="back"></div>
                                    <div class="flying-card clubs">
                                        <img class="w-100" src="<?php echo e(asset($activeTemplateTrue . 'images/play/cards/16.png')); ?>">
                                    </div>
                                </div>
                                <div class="card-holder">
                                    <div class="back"></div>
                                    <div class="flying-card clubs">
                                        <img class="w-100" src="<?php echo e(asset($activeTemplateTrue . 'images/play/cards/50.png')); ?>">
                                    </div>
                                </div>
                                <div class="card-holder">
                                    <div class="back"></div>
                                    <div class="flying-card clubs">
                                        <img class="w-100" src="<?php echo e(asset($activeTemplateTrue . 'images/play/cards/08.png')); ?>">
                                    </div>
                                </div>
                                <div class="card-holder">
                                    <div class="back"></div>
                                    <div class="flying-card clubs">
                                        <img class="w-100" src="<?php echo e(asset($activeTemplateTrue . 'images/play/cards/47.png')); ?>">
                                    </div>
                                </div>
                                <div class="card-holder">
                                    <div class="back"></div>
                                    <div class="flying-card clubs">
                                        <img class="w-100" src="<?php echo e(asset($activeTemplateTrue . 'images/play/cards/24.png')); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="d-none res res-thumb-img t--60px m-0">
                                <div class="res--card--img">
                                    <div class="back"></div>
                                    <div class="flying-card clubs resImg">
                                        <img class="w-100" src="<?php echo e(asset($activeTemplateTrue . 'images/play/cards/24.png')); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 mt-lg-0 mt-5">
                <div class="game-details-right">
                    <form id="game" method="post">
                        <?php echo csrf_field(); ?>

                        <h3 class="f-size--28 mb-4 text-center"><?php echo app('translator')->get('Current Balance'); ?>: <span class="base--color"><span class="bal"><?php echo e(showAmount(auth()->user()->balance)); ?></span> <?php echo e($general->cur_text); ?></span>
                        </h3>
                        <div class="form-group">
                            <div class="input-group mb-3">
                                <input class="form-control amount-field custom-amount-input" name="invest" type="text" placeholder="<?php echo app('translator')->get('Enter Amount'); ?>" autocomplete="off" required>
                                <span class="input-group-text" id="basic-addon2"><?php echo e($general->cur_text); ?></span>
                            </div>
                            <small class="form-text text-muted"><i class="fas fa-info-circle mr-2"></i> <?php echo app('translator')->get('Minimum'); ?>
                                : <?php echo e(showAmount($game->min_limit)); ?> <?php echo e($general->cur_text); ?> | <?php echo app('translator')->get('Maximum'); ?>
                                : <?php echo e(showAmount($game->max_limit)); ?> <?php echo e($general->cur_text); ?> | <span class="text--warning"><?php echo app('translator')->get('Win Amount'); ?> <?php if($game->invest_back == 1): ?>
                                    <?php echo e(showAmount($game->win + 100)); ?>

                                    <?php else: ?>
                                    <?php echo e(showAmount($game->win)); ?>

                                    <?php endif; ?> %</span></small>
                        </div>
                        <div class="form-group justify-content-center d-flex mt-5">
                            <div class="single-select red">
                                <img class="red" src="<?php echo e(asset($activeTemplateTrue . 'images/play/cards/27.png')); ?>" alt="">
                            </div>
                            <div class="single-select black">
                                <img class="black" src="<?php echo e(asset($activeTemplateTrue . 'images/play/cards/40.png')); ?>" alt="">
                            </div>
                        </div>

                        <input name="choose" type="hidden">
                        <input name="type" type="hidden" value="ht">

                        <div class="mt-5 text-center">
                            <button class="cmn-btn w-100 text-center" type="submit"><?php echo app('translator')->get('Play Now'); ?></button>
                            <a class="game-instruction mt-2" data-bs-toggle="modal" data-bs-target="#exampleModalCenter"><?php echo app('translator')->get('Game Instruction'); ?> <i class="las la-info-circle"></i></a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content section--bg">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle"><?php echo app('translator')->get('Game Rule'); ?></h5>
                <button class="btn-close" data-bs-dismiss="modal" type="button" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php echo $game->instruction ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style-lib'); ?>
<link href="<?php echo e(asset($activeTemplateTrue . 'css/deck.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset($activeTemplateTrue . 'css/card.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('style'); ?>
<style type="text/css">
    .game-details-left {
        padding: 10px;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('script-lib'); ?>
<script type="text/javascript" src="<?php echo e(asset($activeTemplateTrue . 'js/deck.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset($activeTemplateTrue . 'js/deckinit.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset($activeTemplateTrue . 'js/cardgame.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('script'); ?>
<script>
    "use strict";
        $('input[name=invest]').keypress(function(e) {
            var character = String.fromCharCode(e.keyCode)
            var newValue = this.value + character;
            if (isNaN(newValue) || hasDecimalPlace(newValue, 3)) {
                e.preventDefault();
                return false;
            }
        });

        function hasDecimalPlace(value, x) {
            var pointIndex = value.indexOf('.');
            return pointIndex >= 0 && pointIndex < value.length - x;
        }

        $('#game').on('submit', function(e) {
            e.preventDefault();
            beforeProcess();
            var data = $(this).serialize();
            var url = '<?php echo e(route('user.play.game.invest', 'card_finding')); ?>';
            game(data, url);
        });


        function startGame(data) {
            animationCard(data);
            $('button[type=submit]').html('<i class="la la-gear fa-spin"></i> Playing...');
            timerA = setInterval(function() {
                succOrError();
                endGame(data);
            }, 10110);
            $('button[type=submit]').html('<i class="la la-gear fa-spin"></i> Playing...');
        }

        function animationCard(data) {
            $('.flying').addClass('d-none');
            $('#cards').removeClass('d-none');
            deck.sort()
            deck.sort()
            deck.sort()
            deck.sort()
            deck.sort()
            deck.sort()
            deck.fan()
            var img = `<?php echo e(asset($activeTemplateTrue . 'images/play/cards/')); ?>/${card(data.result)}.png`;
            setTimeout(function() {
                $('.resImg').find('img').attr('src', img)
                $('#cards').addClass('op');
                $('.res').removeClass('d-none');
            }, 10110);
        }


        function success(data) {

            $('.win-loss-popup').addClass('active');
            $('.win-loss-popup__body').find('img').addClass('d-none');
            if (data.type == 'success') {
                $('.win-loss-popup__body').find('.win').removeClass('d-none');
            } else {
                $('.win-loss-popup__body').find('.lose').removeClass('d-none');
            }
            $('.win-loss-popup__footer').find('.data-result').text(data.result);


            var bal = parseFloat(data.bal);
            $('.bal').html(bal.toFixed(2));
            $('button[type=submit]').html('Play');
            $('button[type=submit]').removeAttr('disabled');
            $('.single-select').removeClass('active');
            $('.single-select').removeClass('op');
            $('.single-select').find('img').removeClass('op');
            $('img').removeClass('op');
        }

        function endGame(data) {
            var url = "<?php echo e(route('user.play.game.end', 'card_finding')); ?>";
            complete(data, url);
        }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/odds_frenzy/core/resources/views/templates/basic/user/games/card_finding.blade.php ENDPATH**/ ?>