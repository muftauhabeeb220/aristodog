<header class="header">
    <div class="header__bottom">
        <div class="container">
            <nav class="navbar navbar-expand-xl align-items-center p-0">
                <a class="site-logo site-title" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(getImage(getFilePath('logoIcon') . '/logo.png')); ?>" alt="site-logo"><span class="logo-icon"><i class="flaticon-fire"></i></span></a>
                <button class="navbar-toggler ml-auto" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" type="button" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="menu-toggle"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <?php if(auth()->guard()->check()): ?>
                    <ul class="navbar-nav main-menu m-auto">
                        <li><a href="<?php echo e(route('user.home')); ?>"><?php echo app('translator')->get('Dashboard'); ?></a></li>
                        <li class="menu_has_children">
                            <a href="#"><?php echo app('translator')->get('Deposit'); ?></a>
                            <ul class="sub-menu">
                                <li><a href="<?php echo e(route('user.deposit.index')); ?>"><?php echo app('translator')->get('Deposit'); ?></a></li>
                                <li><a href="<?php echo e(route('user.deposit.history')); ?>"><?php echo app('translator')->get('Deposit Log'); ?></a></li>
                            </ul>
                        </li>
                        <li class="menu_has_children">
                            <a href="#"><?php echo app('translator')->get('Withdraw'); ?></a>
                            <ul class="sub-menu">
                                <li><a href="<?php echo e(route('user.withdraw')); ?>"><?php echo app('translator')->get('Withdraw'); ?></a></li>
                                <li><a href="<?php echo e(route('user.withdraw.history')); ?>"><?php echo app('translator')->get('Withdraw Log'); ?></a>
                                </li>
                            </ul>
                        </li>
                        <li><a href="<?php echo e(route('user.referrals')); ?>"><?php echo app('translator')->get('Referrals'); ?></a></li>
                        <li class="menu_has_children">
                            <a href="#"><?php echo app('translator')->get('Reports'); ?></a>
                            <ul class="sub-menu">
                                <li><a href="<?php echo e(route('user.game.log')); ?>"><?php echo app('translator')->get('Game Log'); ?></a></li>
                                <li><a href="<?php echo e(route('user.commission.log')); ?>"><?php echo app('translator')->get('Commission Log'); ?></a></li>
                                <li><a href="<?php echo e(route('user.transactions')); ?>"><?php echo app('translator')->get('Transactions'); ?></a></li>
                            </ul>
                        </li>
                        <li class="menu_has_children">
                            <a href="#"><?php echo app('translator')->get('Support'); ?></a>
                            <ul class="sub-menu">
                                <li><a href="<?php echo e(route('ticket.open')); ?>"><?php echo app('translator')->get('Open New Ticket'); ?></a></li>
                                <li><a href="<?php echo e(route('ticket.index')); ?>"><?php echo app('translator')->get('My Tickets'); ?></a></li>
                            </ul>
                        </li>
                        <li class="menu_has_children">
                            <a href="#"><?php echo app('translator')->get('Account'); ?></a>
                            <ul class="sub-menu">
                                <li><a href="<?php echo e(route('user.profile.setting')); ?>"><?php echo app('translator')->get('Profile Setting'); ?></a></li>
                                <li><a href="<?php echo e(route('user.change.password')); ?>"><?php echo app('translator')->get('Change Password'); ?></a></li>
                                <li><a href="<?php echo e(route('user.twofactor')); ?>"><?php echo app('translator')->get('2FA Security'); ?></a></li>
                            </ul>
                        </li>
                    </ul>
                    <?php endif; ?>

                    <div class="nav-right">

                        <a href="<?php echo e(route('user.logout')); ?>"><i class="las la-sign-out-alt"></i> <?php echo app('translator')->get('Logout'); ?>
                        </a>

                        <?php if($general->language): ?>
                        <select class="langSel">
                            <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->code); ?>" <?php if(session('lang')==$item->code): ?> selected <?php endif; ?>><?php echo e(__($item->name)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php endif; ?>
                    </div>
                </div>
            </nav>
        </div>
    </div>
</header>

<?php $__env->startPush('style'); ?>
<style>
    .nav-right .langSel {
        padding: 7px 20px;
        height: 37px;
    }
</style>
<?php $__env->stopPush(); ?>
<?php /**PATH /opt/lampp/htdocs/odds_frenzy/core/resources/views/templates/basic/partials/user_header.blade.php ENDPATH**/ ?>