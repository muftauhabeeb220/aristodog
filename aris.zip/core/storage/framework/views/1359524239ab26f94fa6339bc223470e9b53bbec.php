<?php $__env->startSection('content'); ?>
    <section class="blog-details-section pt-150 pb-150">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="blog-details-wrapper">
                        <div class="post-details-header">
                            <span class="post-card__date text--base"><?php echo e($blog->created_at->format('d M, Y')); ?></span>
                            <h3 class="post-title"><?php echo e(__(@$blog->data_values->title)); ?></h3>
                        </div>
                        <div class="post-details-thumb"><img class="w-100" src="<?php echo e(getImage('assets/images/frontend/blog/' . @$blog->data_values->image, '700x500')); ?>" alt="image"></div>
                        <div class="blog-details-content">
                            <?php echo $blog->data_values->description ?>
                        </div>
                    </div>
                    <div class="fb-comments" data-href="<?php echo e(route('blog.details', [$blog->id, slug($blog->data_values->title)])); ?>" data-numposts="5"></div>

                    <ul class="list list--row social-list justify-content-center mt-4">
                        <li>
                            <a target="_blank" class="t-link social-list__icon" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode(url()->current())); ?>">
                                <i class="lab la-facebook-f"></i>
                            </a>
                        </li>
                        <li>
                            <a target="_blank" class="t-link social-list__icon" href="https://twitter.com/intent/tweet?text=<?php echo e(__(@$blog->data_values->title)); ?>%0A<?php echo e(url()->current()); ?>">
                                <i class="lab la-twitter"></i>
                            </a>
                        </li>
                        <li>
                            <a target="_blank" class="t-link social-list__icon" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=<?php echo e(urlencode(url()->current())); ?>&amp;title=<?php echo e(__(@$blog->data_values->title)); ?>&amp;summary=<?php echo e(__(@$blog->data_values->description)); ?>">
                                <i class="lab la-linkedin-in"></i>
                            </a>
                        </li>
                        <li>
                            <a target="_blank" class="t-link social-list__icon" href="http://pinterest.com/pin/create/button/?url=<?php echo e(urlencode(url()->current())); ?>&description=<?php echo e(__(@$blog->data_values->title)); ?>&media=<?php echo e(getImage('assets/images/frontend/blog/' . $blog->data_values->image, '840x480')); ?>">
                                <i class="lab la-pinterest"></i>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="col-lg-4">
                    <aside class="sidebar">
                        <div class="widget">
                            <h5 class="widget-title"><?php echo app('translator')->get('Latest Blog'); ?></h5>
                            <ul class="small-post-list">
                                <?php $__currentLoopData = $latestBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="small-post">
                                        <div class="small-post__thumb"><img src="<?php echo e(getImage('assets/images/frontend/blog/thumb_' . @$blog->data_values->image, '350x250')); ?>" alt="image">
                                        </div>
                                        <div class="small-post__content">
                                            <h6>
                                                <a href="<?php echo e(route('blog.details', [slug(@$blog->data_values->title), $blog->id])); ?>"><?php echo e(__(@$blog->data_values->title)); ?></a>
                                            </h6>
                                            <a class="date" href="<?php echo e(route('blog.details', [slug(@$blog->data_values->title), $blog->id])); ?>"><?php echo e(showDateTime($blog->created_at)); ?></a>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="widget">
                            <h5 class="widget-title"><?php echo app('translator')->get('Most Views'); ?></h5>
                            <ul class="small-post-list">
                                <?php $__empty_1 = true; $__currentLoopData = $mostViews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <li class="small-post">
                                        <div class="small-post__thumb"><img src="<?php echo e(getImage('assets/images/frontend/blog/thumb_' . @$blog->data_values->image, '350x250')); ?>" alt="image">
                                        </div>
                                        <div class="small-post__content">
                                            <h6>
                                                <a href="<?php echo e(route('blog.details', [slug(@$blog->data_values->title), $blog->id])); ?>"><?php echo e(__(@$blog->data_values->title)); ?></a>
                                            </h6>
                                            <a class="date" href="<?php echo e(route('blog.details', [slug(@$blog->data_values->title), $blog->id])); ?>"><?php echo e(@showDateTime($blog->created_at)); ?></a>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </aside>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('fbComment'); ?>
    <?php echo loadExtension('fb-comment') ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/odds_frenzy/core/resources/views/templates/basic/blog_details.blade.php ENDPATH**/ ?>