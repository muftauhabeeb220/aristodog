<?php $__env->startSection('content'); ?>
    <?php
        $kyc = getContent('user_kyc.content', true);
    ?>
    <section class="pt-120 pb-120">
        <div class="container">
            <div class="row mb-3">
                <div class="col-md-12">
                    <?php if($user->kv == 0): ?>
                        <div class="d-widget" role="alert">
                            <h4 class="alert-heading text--danger"><?php echo app('translator')->get('KYC Verification required'); ?></h4>
                            <hr>
                            <p class="mb-0"><?php echo e(__($kyc->data_values->verification_content)); ?> <a class="text--base" href="<?php echo e(route('user.kyc.form')); ?>"><?php echo app('translator')->get('Click Here to Verify'); ?></a></p>
                        </div>
                    <?php elseif($user->kv == 2): ?>
                        <div class="d-widget" role="alert">
                            <h4 class="alert-heading text--warning"><?php echo app('translator')->get('KYC Verification pending'); ?></h4>
                            <hr>
                            <p class="mb-0"><?php echo e(__($kyc->data_values->pending_content)); ?> <a class="text--base" href="<?php echo e(route('user.kyc.data')); ?>"><?php echo app('translator')->get('See KYC Data'); ?></a></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="row mb-3">
                <div class="col-lg-4 col-md-6 mb-30">
                    <div class="d-widget dashbaord-widget-card d-widget-balance">
                        <div class="d-widget-icon">
                            <i class="las la-money-bill-wave"></i>
                        </div>
                        <div class="d-widget-content">
                            <p><?php echo app('translator')->get('Total Balance'); ?></p>
                            <h2 class="title"><?php echo e(showAmount($widget['total_balance'])); ?> <?php echo e($general->cur_text); ?></h2>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-30">
                    <div class="d-widget dashbaord-widget-card d-widget-deposit">
                        <div class="d-widget-icon">
                            <i class="las la-wallet"></i>
                        </div>
                        <div class="d-widget-content">
                            <p><?php echo app('translator')->get('Total Deposit'); ?></p>
                            <h2 class="title"><?php echo e(showAmount($widget['total_deposit'])); ?> <?php echo e($general->cur_text); ?></h2>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-30">
                    <div class="d-widget dashbaord-widget-card d-widget-withdraw">
                        <div class="d-widget-icon">
                            <i class="las la-hand-holding-usd"></i>
                        </div>
                        <div class="d-widget-content">
                            <p><?php echo app('translator')->get('Total Withdraw'); ?></p>
                            <h2 class="title"><?php echo e(showAmount($widget['total_withdrawn'])); ?> <?php echo e($general->cur_text); ?></h2>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-30">
                    <div class="d-widget dashbaord-widget-card d-widget-invest">
                        <div class="d-widget-icon">
                            <i class="las la-cash-register"></i>
                        </div>
                        <div class="d-widget-content">
                            <p><?php echo app('translator')->get('Total Invest'); ?></p>
                            <h2 class="title"><?php echo e(showAmount($widget['total_invest'])); ?> <?php echo e($general->cur_text); ?></h2>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-30">
                    <div class="d-widget dashbaord-widget-card d-widget-win">
                        <div class="d-widget-icon">
                            <i class="las la-trophy"></i>
                        </div>
                        <div class="d-widget-content">
                            <p><?php echo app('translator')->get('Total Win'); ?></p>
                            <h2 class="title"><?php echo e(showAmount($widget['total_win'])); ?> <?php echo e($general->cur_text); ?></h2>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-30">
                    <div class="d-widget dashbaord-widget-card d-widget-loss">
                        <div class="d-widget-icon">
                            <i class="las la-money-bill-alt"></i>
                        </div>
                        <div class="d-widget-content">
                            <p><?php echo app('translator')->get('Total Loss'); ?></p>
                            <h2 class="title"><?php echo e(showAmount($widget['total_loss'])); ?> <?php echo e($general->cur_text); ?></h2>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center">
                <?php $__empty_1 = true; $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-xl-3 col-lg-4 col-sm-6 mb-30 wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.3s">
                        <div class="game-card style--two">
                            <div class="game-card__thumb">
                                <img src="<?php echo e(getImage(getFilePath('game') . '/' . $game->image, getFileSize('game'))); ?>" alt="image">
                            </div>
                            <div class="game-card__content">
                                <h4 class="game-name"><?php echo e(__($game->name)); ?></h4>
                                <a class="cmn-btn d-block btn-sm btn--capsule mt-3 text-center" href="<?php echo e(route('user.play.game', $game->alias)); ?>"><?php echo app('translator')->get('Play Now'); ?></a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="text-center"><?php echo e(__($emptyMessage)); ?></h5>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>


<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/aristodog/core/resources/views/templates/basic/user/dashboard.blade.php ENDPATH**/ ?>