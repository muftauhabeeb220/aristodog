<?php $__env->startSection('content'); ?>
<?php
$gesBon = App\Models\GuessBonus::get();
?>
<section class="pt-120 pb-120">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="game-details-left number--guess">
                    <div class="game-details-left__body d-flex align-items-center">
                        <img class="vert-move-down vert down d-none" src="<?php echo e(asset($activeTemplateTrue . 'images/play/Down-arrow.png')); ?>" height="70" width="70" />
                        <img class="vert-move-up vert up d-none" src="<?php echo e(asset($activeTemplateTrue . 'images/play/up-arrow.png')); ?>" height="70" width="70" />
                        <div class="text">
                            <h2 class="custom-font base--color text-center"><?php echo app('translator')->get('You Will Get'); ?> <?php echo e($gesBon->count()); ?> <?php echo app('translator')->get('Chances Per Invest'); ?></h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 mt-lg-0 mt-5">
                <div class="game-details-right">
                    <form id="game">
                        <h3 class="f-size--28 mb-4 text-center"><?php echo app('translator')->get('Current Balance'); ?> : <span class="base--color"><span class="bal"><?php echo e(showAmount(auth()->user()->balance)); ?></span> <?php echo e(__($general->cur_text)); ?></span>
                        </h3>
                        <div class="form-group">
                            <div class="input-group amf mb-3">
                                <input class="form-control amount-field" name="invest" type="text" placeholder="<?php echo app('translator')->get('Enter amount'); ?>">
                                <span class="input-group-text" id="basic-addon2" onclick="myFunc()"><?php echo e(__($general->cur_text)); ?></span>
                            </div>
                            <small class="form-text text-muted"><i class="fas fa-info-circle mr-2"></i> <?php echo app('translator')->get('Minimum'); ?>
                                : <?php echo e(showAmount($game->min_limit)); ?> <?php echo e(__($general->cur_text)); ?>

                                | <?php echo app('translator')->get('Maximum'); ?>
                                : <?php echo e(showAmount($game->max_limit)); ?> <?php echo e(__($general->cur_text)); ?> | <span class="text--warning"><?php echo app('translator')->get('Win Bonus For This Chance'); ?> <span class="bon"><?php echo e(__($gesBon->first()->percent)); ?>%</span></small>
                        </div>
                        <div class="invBtn mt-5 text-center">
                            <button class="cmn-btn w-100 my-submit-btn text-center" type="submit"><?php echo app('translator')->get('Start Game'); ?></button>
                            <a class="game-instruction mt-2" data-bs-toggle="modal" data-bs-target="#exampleModalCenter"><?php echo app('translator')->get('Game Instruction'); ?> <i class="las la-info-circle"></i></a>
                        </div>
                    </form>

                    <form class="startGame" id="start">
                        <?php echo csrf_field(); ?>
                        <input name="game_id" type="hidden">
                        <div class="numberGs numHide">
                            <div class="form-group">
                                <input class="form-control guess" name="number" type="number" placeholder="<?php echo app('translator')->get('Guess The Number'); ?>" autocomplete="off">
                            </div>
                            <button class="btn cmn-btn gmg w-100" type="submit"><?php echo app('translator')->get('Guess The Number'); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content section--bg">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle"><?php echo app('translator')->get('Game Rule'); ?></h5>
                <button class="btn-close" data-bs-dismiss="modal" type="button" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php echo $game->instruction ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<link href="<?php echo e(asset($activeTemplateTrue . 'css/guess.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('script-lib'); ?>
<script src="<?php echo e(asset($activeTemplateTrue . 'js/guess.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('style'); ?>
<style type="text/css">
    .game-details-left__body {
        height: 100%;
        width: 100%;
        background: #d3e0f71a;
        backdrop-filter: blur(4px);
        -webkit-backdrop-filter: blur(4px);
        border-radius: 10px;
        padding: 20px;
    }

    .game-details-left {
        padding: 30px;
        background: url('<?php echo e(asset($activeTemplateTrue . 'images/play/number.png')); ?>');
        background-size: 100% 100%;
    }

    .game-details-left h2 {
        font-size: 40px;
        text-shadow: none;
    }

    @media screen and (max-width:991px) {
        .number--guess {
            min-height: 520px;
        }
    }

    @media screen and (max-width:767px) {
        .text h2 {
            font-size: 36px;
            padding: 0 30px
        }
    }

    @media screen and (max-width:450px) {
        .number--guess {
            min-height: 390px
        }
    }

    @media screen and (max-width:575px) {
        .text h2 {
            font-size: 30px;
            padding: 0;
        }
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script>
    "use strict";
        function color() {
            var myArray = [
                "#0060651a",
                "#654f001a",
                "#6500001a",
                "#5f00651a",
                "#000c651a",
                "#0057651a",
            ];

            var randomItem = myArray[Math.floor(Math.random() * myArray.length)];
            return randomItem;
        }

        function myFunc() {
            $('.game-details-left__body').css('background', color());
        }

        $('input[name=invest]').keypress(function(e) {
            var character = String.fromCharCode(e.keyCode)
            var newValue = this.value + character;
            if (isNaN(newValue) || hasDecimalPlace(newValue, 3)) {
                e.preventDefault();
                return false;
            }
        });

        function hasDecimalPlace(value, x) {
            var pointIndex = value.indexOf('.');
            return pointIndex >= 0 && pointIndex < value.length - x;
        }

        $('#game').on('submit', function(e) {
            e.preventDefault();
            var data = $(this).serialize();
            var url = "<?php echo e(route('user.play.game.invest', 'number_guess')); ?>";
            game(data, url);
        });

        $('#start').on('submit', function(e) {
            e.preventDefault();
            var data = $(this).serialize();
            var url = "<?php echo e(route('user.play.game.end', 'number_guess')); ?>";
            var bon = <?php echo e($gesBon->first()->percent); ?>

            start(url, data, bon);
        });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make($activeTemplate . 'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/odds_frenzy/core/resources/views/templates/basic/user/games/number_guess.blade.php ENDPATH**/ ?>