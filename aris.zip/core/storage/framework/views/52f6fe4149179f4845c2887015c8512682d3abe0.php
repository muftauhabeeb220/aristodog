<?php $__env->startSection('content'); ?>
    <?php
        $kyc = getContent('user_kyc.content', true);
    ?>
    <section class="pt-120 pb-120">
        <div class="container">
            <div class="row mb-3">
                <div class="col-md-12">
                    <?php if($user->kv == 0): ?>
                        <div class="d-widget" role="alert">
                            <h4 class="alert-heading text--danger"><?php echo app('translator')->get('KYC Verification required'); ?></h4>
                            <hr>
                            <p class="mb-0"><?php echo e(__($kyc->data_values->verification_content)); ?> <a class="text--base" href="<?php echo e(route('user.kyc.form')); ?>"><?php echo app('translator')->get('Click Here to Verify'); ?></a></p>
                        </div>
                    <?php elseif($user->kv == 2): ?>
                        <div class="d-widget" role="alert">
                            <h4 class="alert-heading text--warning"><?php echo app('translator')->get('KYC Verification pending'); ?></h4>
                            <hr>
                            <p class="mb-0"><?php echo e(__($kyc->data_values->pending_content)); ?> <a class="text--base" href="<?php echo e(route('user.kyc.data')); ?>"><?php echo app('translator')->get('See KYC Data'); ?></a></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php if(Auth::user()->txHash==NULL || Auth::user()->nft_status==0): ?>
            
            <a href="#" class="mybonus btn btn-info btn-sm">Burn NFT</a>
            <?php endif; ?>
            <div class="row mb-3">
                <div class="col-lg-4 col-md-6 mb-30">
                    <div class="d-widget dashbaord-widget-card d-widget-balance">
                        <div class="d-widget-icon">
                            <i class="las la-money-bill-wave"></i>
                        </div>
                        <div class="d-widget-content">
                            <p><?php echo app('translator')->get('Total Balance'); ?></p>
                            <h2 class="title"><?php echo e(showAmount($widget['total_balance'])); ?> <?php echo e($general->cur_text); ?></h2>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-30">
                    <div class="d-widget dashbaord-widget-card d-widget-deposit">
                        <div class="d-widget-icon">
                            <i class="las la-wallet"></i>
                        </div>
                        <div class="d-widget-content">
                            <p><?php echo app('translator')->get('Total Deposit'); ?></p>
                            <h2 class="title"><?php echo e(showAmount($widget['total_deposit'])); ?> <?php echo e($general->cur_text); ?></h2>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-30">
                    <div class="d-widget dashbaord-widget-card d-widget-withdraw">
                        <div class="d-widget-icon">
                            <i class="las la-hand-holding-usd"></i>
                        </div>
                        <div class="d-widget-content">
                            <p><?php echo app('translator')->get('Total Withdraw'); ?></p>
                            <h2 class="title"><?php echo e(showAmount($widget['total_withdrawn'])); ?> <?php echo e($general->cur_text); ?></h2>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-30">
                    <div class="d-widget dashbaord-widget-card d-widget-invest">
                        <div class="d-widget-icon">
                            <i class="las la-cash-register"></i>
                        </div>
                        <div class="d-widget-content">
                            <p><?php echo app('translator')->get('Total Invest'); ?></p>
                            <h2 class="title"><?php echo e(showAmount($widget['total_invest'])); ?> <?php echo e($general->cur_text); ?></h2>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-30">
                    <div class="d-widget dashbaord-widget-card d-widget-win">
                        <div class="d-widget-icon">
                            <i class="las la-trophy"></i>
                        </div>
                        <div class="d-widget-content">
                            <p><?php echo app('translator')->get('Total Win'); ?></p>
                            <h2 class="title"><?php echo e(showAmount($widget['total_win'])); ?> <?php echo e($general->cur_text); ?></h2>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-30">
                    <div class="d-widget dashbaord-widget-card d-widget-loss">
                        <div class="d-widget-icon">
                            <i class="las la-money-bill-alt"></i>
                        </div>
                        <div class="d-widget-content">
                            <p><?php echo app('translator')->get('Total Loss'); ?></p>
                            <h2 class="title"><?php echo e(showAmount($widget['total_loss'])); ?> <?php echo e($general->cur_text); ?></h2>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center">
                <?php $__empty_1 = true; $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-xl-3 col-lg-4 col-sm-6 mb-30 wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.3s">
                        <div class="game-card style--two">
                            <div class="game-card__thumb">
                                <img src="<?php echo e(getImage(getFilePath('game') . '/' . $game->image, getFileSize('game'))); ?>" alt="image">
                            </div>
                            <div class="game-card__content">
                                <h4 class="game-name"><?php echo e(__($game->name)); ?></h4>
                                <a class="cmn-btn d-block btn-sm btn--capsule mt-3 text-center" href="<?php echo e(route('user.play.game', $game->alias)); ?>"><?php echo app('translator')->get('Play Now'); ?></a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="text-center"><?php echo e(__($emptyMessage)); ?></h5>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <?php if(Auth::user()->txHash==NULL || Auth::user()->nft_status==0): ?>

    <div class="modal fade" id="cronModal" role="dialog" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle"><?php echo app('translator')->get('Burn Instruction'); ?></h5>
                    <span class="btn-close" data-bs-dismiss="modal" type="button" aria-label="Close"></span>
                </div>
                <div class="modal-body">
                    <h3 class="text--danger text-center"><?php echo app('translator')->get('Burn Rug Get Free Game Credits'); ?></h3>
                    <h5 class="text--danger text-center"><?php echo app('translator')->get('Send the rug to the burn address provided for the blockchain'); ?></h5>
                    
                    <p class="text-dark">
                        <?php
                            $wallets = App\Models\Wallet::get();
                        ?>
                        <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



                        <label style="margin: 0px" class="font-weight-bold text-black"><?php echo app('translator')->get($wallet->network); ?></label>
                        <div class="input-group">
                            <input class="form-control form-control-lg bg-black copytextcontent"  name="text" type="text" value=" <?php echo e($wallet->wallet); ?>" readonly>
                            <span class="input-group-text copytext btn--primary copyBoard border-0" > <?php echo app('translator')->get('Copy'); ?> </span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        <form action="submitNFT" class ="my-5" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>


                            
                            <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" class="custom-control-input" id="customRadio<?php echo e($key); ?>" name="wallet" value="<?php echo e($item->id); ?>">
                                <label class="custom-control-label" for="customRadio<?php echo e($key); ?>"><?php echo e($item->network); ?></label>
                              </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            <label class="font-weight-bold bg-info text-light"><?php echo app('translator')->get('Paste Your Wallet here'); ?></label>
                            <div class="input-group">
                            <input class="form-control form-control" placeholder="Paste your wallet here"  name="nft" type="text">
                            <input type="submit" value="Paste Your Wallet Address" class="input-group-text d-block copytext btn--primary copyBoard border-0">
                        </div>
                        </form>
                        

                </div>
            </div>
        </div>
    </div>

    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

<?php if(Auth::user()->txHash==NULL || Auth::user()->nft_status==0): ?>

<script>
    $(document).ready(function() {

            $(document).on('click', '.mybonus', function() {
                $("#cronModal").modal('show')
            })
        });


        $(document).on( 'click', '.copyBoard', function() {
            var copyText =  $(this).closest('.input-group').children('.copytextcontent'); //document.getElementById("referralURL");
            // alert(copyText);
            // console.log(copyText.val());
            copyText.select();
            // // copyText.setSelectionRange(0, 99999);
            document.execCommand("copy");
            iziToast.success({
                message: "Copied: " + copyText.val(),
                position: "topRight"
            });
        });

        // function startProcess() {
        //     if ($('#inp_amount').val()) {
        //         // run metamsk functions here
        //         EThAppDeploy.loadEtherium();
        //     } else {
        //         alert('Please Enter Valid Amount');
        //     }
        // }

        $(".payNFT").click(function(){
            EThAppDeploy.loadEtherium();
        })



        EThAppDeploy = {
            loadEtherium: async () => {
                if (typeof window.ethereum !== 'undefined') {
                    EThAppDeploy.web3Provider = ethereum;
                    EThAppDeploy.requestAccount(ethereum);
                } else {
                    alert(
                        "Not able to locate an Ethereum connection, please install a Metamask wallet"
                    );
                }
            },
            /****
             * Request A Account
             * **/
            requestAccount: async (ethereum) => {
                ethereum
                    .request({
                        method: 'eth_requestAccounts'
                    })
                    .then((resp) => {
                        //do payments with activated account
                        EThAppDeploy.payNow(ethereum, resp[0]);
                    })
                    .catch((err) => {
                        // Some unexpected error.
                        // console.log(err);
                        alert(err.message);
                    });
            },
            /***
             *
             * Do Payment
             * */
            payNow: async (ethereum, from) => {
                var amount = "<?php echo e(env('ETH_PAYMENT')); ?>"; //$('#inp_amount').val();
                ethereum
                    .request({
                        method: 'eth_sendTransaction',
                        params: [{
                            from: from,
                            to: "<?php echo e(env('MY_WALLET')); ?>",
                            value: '0x' + ((amount * 1000000000000000000).toString(16)),
                        }, ],
                    })
                    .then((txHash) => {
                        if (txHash) {
                            console.log(txHash);
                            storeTransaction(txHash, amount);
                        } else {
                            // console.log("error 2");
                            alert("Something went wrong. Please try again");
                        }
                    })
                    .catch((error) => {
                        // console.log("error");
                        // console.log(error);
                        alert(error.message);
                    });
            },
        }
        /***
         *
         * @param Transaction id
         *
         */
        function storeTransaction(txHash, amount) {
            $.ajax({
                url: "<?php echo e('submitNFT'); ?>",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type: 'POST',
                data: {
                    txHash: txHash,
                    amount: amount,
                },
                success: function (response) {
                    // reload page after success
                    window.location.reload();
                }
            });
        }


</script>
<?php endif; ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/odds_frenzy/core/resources/views/templates/basic/user/dashboard.blade.php ENDPATH**/ ?>