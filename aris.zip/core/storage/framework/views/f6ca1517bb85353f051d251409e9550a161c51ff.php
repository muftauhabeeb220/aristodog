<?php $__env->startSection('content'); ?>
    <section class="pt-120 pb-120">
        <div class="container">
            <div class="d-flex justify-content-center">
                <div class="verification-code-wrapper">
                    <div class="verification-area">
                        <div class="d-flex justify-content-center border-bottom flex-wrap pb-3 text-center">
                            <h5><?php echo app('translator')->get('Verify Email'); ?></h5>
                        </div>
                        <form class="submit-form row gy-3" action="<?php echo e(route('user.verify.email')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <p class="pt-3"><?php echo app('translator')->get('A 6 digit verification code sent to your email address'); ?>: <?php echo e(showEmailAddress(auth()->user()->email)); ?></p>

                            <?php echo $__env->make($activeTemplate . 'partials.verification_code', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <div class="col-12">
                                <button class="cmn-btn w-100" type="submit"><?php echo app('translator')->get('Submit'); ?></button>
                            </div>

                            <div class="mb-3">
                                <p>
                                    <?php echo app('translator')->get('If you don\'t get any code'); ?>, <a class="text--base" href="<?php echo e(route('user.send.verify.code', 'email')); ?>"> <?php echo app('translator')->get('Try again'); ?></a>
                                </p>

                                <?php if($errors->has('resend')): ?>
                                    <small class="text--danger d-block"><?php echo e($errors->first('resend')); ?></small>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/odds_frenzy/core/resources/views/templates/basic/user/auth/authorization/email.blade.php ENDPATH**/ ?>