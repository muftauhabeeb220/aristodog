@props(['route' => ''])

<a class="btn btn-sm btn-outline--primary" href="{{ $route }}">
    <i class="la la-undo"></i> @lang('Back')
</a>
